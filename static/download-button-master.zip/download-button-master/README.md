# Build a Download Button full of Micro Interactions

[**DEMO**](https://lmgonzalves.github.io/download-button/)

[**TUTORIAL**](https://scotch.io/tutorials/build-a-download-button-full-of-micro-interactions)
